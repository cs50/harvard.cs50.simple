#include <stdio.h>
void pthread_create() {
    printf( "You are about to die! attempt to use pthreads in something not linked\n with them\n" );
}
